Android Views and Widgets Samples Repository
============================================

This repository contains a set of individual Android Studio projects to help you get
started writing/understanding Android views and widgets features.
